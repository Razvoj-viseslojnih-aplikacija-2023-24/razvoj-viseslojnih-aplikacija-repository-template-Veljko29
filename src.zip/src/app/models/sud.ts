export class Sud{
  id!: number;
  naziv!: string;
  adresa!: string;

}
