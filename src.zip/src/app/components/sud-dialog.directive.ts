import { Directive } from '@angular/core';

@Directive({
  selector: '[appSudDialog]'
})
export class SudDialogDirective {

  constructor() { }

}
