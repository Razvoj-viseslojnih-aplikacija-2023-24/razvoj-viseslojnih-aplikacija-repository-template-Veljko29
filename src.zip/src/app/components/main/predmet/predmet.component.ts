import { Component } from '@angular/core';
import { __decorate } from "tslib";

@Component({
  selector: 'app-predmet',
  templateUrl: './predmet.component.html',
  styleUrls: ['./predmet.component.css']
})
export class PredmetComponent {

}
