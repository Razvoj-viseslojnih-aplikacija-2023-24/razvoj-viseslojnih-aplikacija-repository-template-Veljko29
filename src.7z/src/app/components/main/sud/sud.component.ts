import { Component, OnDestroy, OnInit } from '@angular/core';
import { Sud } from 'src/app/models/sud';
import { SudService } from 'src/app/services/sud.service';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-sud',
  templateUrl: './sud.component.html',
  styleUrls: ['./sud.component.css']
})
export class SudComponent implements OnInit, OnDestroy {
  displayedColumns = ['id', 'naziv', 'adresa'];
  dataSource!:MatTableDataSource<Sud>;
  subscription!:Subscription;

  constructor(private service:SudService, public dialog:MatDialog){}

   ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  ngOnInit(): void {
    this.loadData();
  }

  public loadData(){
    this.subscription = this.service.getAllSuds().subscribe(
      (data) => {
        console.log(data);
        this.dataSource = new MatTableDataSource(data);
        //this.dataSource.sort = this.sort;
        //this.dataSource.paginator = this.paginator;
      }
    ),
    (error: Error) => {
      console.log(error.name + ' ' + error.message);
    }
  }

}
