export class Ucesnik{
  id!: number;
  ime!: string;
  prezime!: string;
  mbr!: string;
  status!: string;
}
