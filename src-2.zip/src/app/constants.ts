export const SUD_URL = "http://localhost:8082/sud";
export const UCESNIK_URL = "http://localhost:8082/ucesnik";
export const PREDMET_URL = "http://localhost:8082/predmet";
export const ROCISTE_URL = "http://localhost:8082/rociste";
export const PREDMET_BY_SUD_URL= "http://localhost:8082/predmet/sud";
export const ROCISTE_BY_PREDMET_URL= "http://localhost:8082/rociste/predmet";
export const ROCISTE_BY_UCESNIK_URL= "http://localhost:8082/rociste/ucesnik";
